// Detecta quando a seção está no meio da tela
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('.secao');
    const windowHeight = window.innerHeight;

    sections.forEach(section => {
        const sectionRect = section.getBoundingClientRect();
        const sectionMiddle = sectionRect.top + (sectionRect.height / 2);

        if (sectionMiddle >= 0 && sectionMiddle <= windowHeight) {
            section.classList.add('foco-secao');
            section.classList.remove('desfoque-secao');
        } else {
            section.classList.add('desfoque-secao');
            section.classList.remove('foco-secao');
        }
    });
});


const btnAnterior = document.querySelector('.btnAnterior');
const btnProximo = document.querySelector('.btnProximo');
const containerPerfis = document.querySelector('.containerPerfis');
const perfis = document.querySelectorAll('.perfil');

let indiceAtual = 0;

btnProximo.addEventListener('click', () => {
  if (indiceAtual < perfis.length - 1) {
    indiceAtual++;
  } else {
    indiceAtual = 0; // Volta para o primeiro perfil se chegar ao final
  }
  atualizarCarrossel();
});

btnAnterior.addEventListener('click', () => {
  if (indiceAtual > 0) {
    indiceAtual--;
  } else {
    indiceAtual = perfis.length - 1; // Vai para o último perfil se estiver no primeiro
  }
  atualizarCarrossel();
});

function atualizarCarrossel() {
  const larguraPerfil = document.querySelector('.perfil').offsetWidth;
  containerPerfis.style.transform = `translateX(-${larguraPerfil * indiceAtual}px)`;
}

