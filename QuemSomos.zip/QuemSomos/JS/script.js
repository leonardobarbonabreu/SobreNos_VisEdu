// Detecta quando a seção está no meio da tela
window.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('.secao');
    const windowHeight = window.innerHeight;

    sections.forEach(section => {
        const sectionRect = section.getBoundingClientRect();
        const sectionMiddle = sectionRect.top + (sectionRect.height / 2);

        if (sectionMiddle >= 0 && sectionMiddle <= windowHeight) {
            section.classList.add('foco-secao');
            section.classList.remove('desfoque-secao');
        } else {
            section.classList.add('desfoque-secao');
            section.classList.remove('foco-secao');
        }
    });
});


